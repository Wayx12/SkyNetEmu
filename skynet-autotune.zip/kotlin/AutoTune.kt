package com.skynetemu.autotune

import android.content.Context
import java.io.File

/**
 * Фасад: три вызова на всё приложение.
 *
 * 1) Перед запуском (в фоне):   val r = AutoTune.prepare(ctx, exeFile, activeCooling = true)
 *                               access.applyConfig(r.primary)   // и показать r.warnings
 * 2) Игра запустилась:          AutoTune.markWorking(ctx, r, r.primary)
 * 3) Игра упала:                AutoFix.repair(logText, access, r, attempt)  // и перезапуск
 */
object AutoTune {
    private fun store(ctx: Context) = LastGoodStore(File(ctx.filesDir, "autotune_lastgood.json"))

    /** Вызывать не с главного потока: может скачать свежие правила. */
    fun prepare(ctx: Context, exe: File, activeCooling: Boolean = false): Resolution {
        val game = GameAnalyzer.analyze(exe)
        val device = DeviceDetector.detect(activeCooling)
        return ConfigResolver(RulesLoader.load(ctx), store(ctx)).resolve(game, device)
    }

    fun markWorking(ctx: Context, r: Resolution, cfg: TunedConfig) = store(ctx).save(r.key, cfg)
    fun forget(ctx: Context, r: Resolution) = store(ctx).forget(r.key)
}
