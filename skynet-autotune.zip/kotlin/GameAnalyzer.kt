package com.skynetemu.autotune

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

enum class Platform { WINDOWS, LINUX, UNKNOWN }
enum class Arch { X86, X64, ARM64, UNKNOWN }
enum class Engine { UNITY, UNREAL, GODOT, SOURCE, UNKNOWN }
enum class GfxApi { D3D8, D3D9, D3D10, D3D11, D3D12, OPENGL, VULKAN }

data class GameInfo(
    val exe: File,
    val platform: Platform,
    val arch: Arch,
    val gfxApis: Set<GfxApi>,
    val engine: Engine,
    val usesDotNet: Boolean,
    val antiCheat: String?,
) {
    val highestD3D: GfxApi?
        get() = listOf(GfxApi.D3D12, GfxApi.D3D11, GfxApi.D3D10, GfxApi.D3D9, GfxApi.D3D8)
            .firstOrNull { it in gfxApis }
}

/** Определяет, что за игра, НЕ запуская её: читает заголовок exe/ELF и смотрит файлы рядом. */
object GameAnalyzer {

    fun analyze(exe: File): GameInfo {
        val dir = exe.absoluteFile.parentFile
        val names = dir?.list()?.map { it.lowercase() }?.toSet() ?: emptySet()

        val pe = parsePe(exe)
        val elfArch = if (pe == null) parseElfArch(exe) else null
        val platform = when {
            pe != null -> Platform.WINDOWS
            elfArch != null -> Platform.LINUX
            else -> Platform.UNKNOWN
        }
        val arch = pe?.arch ?: elfArch ?: Arch.UNKNOWN

        // API: сначала таблица импортов, потом (запасной вариант) поиск строк в файлах игры
        val apis = linkedSetOf<GfxApi>()
        pe?.imports?.forEach { dll -> DLL_TO_API[dll]?.let { apis += it } }
        if (apis.isEmpty()) {
            val targets = mutableListOf(exe)
            listOf("unityplayer.dll", "unityplayer.so").forEach { n ->
                if (n in names) targets += File(dir, n)
            }
            val needles = if (platform == Platform.LINUX) LINUX_NEEDLES.keys.toList() else DLL_TO_API.keys.toList()
            for (t in targets) {
                for (hit in scanAscii(t, needles)) {
                    (DLL_TO_API[hit] ?: LINUX_NEEDLES[hit])?.let { apis += it }
                }
            }
        }

        return GameInfo(
            exe = exe,
            platform = platform,
            arch = arch,
            gfxApis = apis,
            engine = detectEngine(exe, dir, names),
            usesDotNet = pe?.dotNet == true,
            antiCheat = detectAntiCheat(dir),
        )
    }

    // ---------- движок / античит ----------

    private fun detectEngine(exe: File, dir: File?, names: Set<String>): Engine {
        val exeName = exe.name.lowercase()
        val path = exe.absolutePath.lowercase().replace('\\', '/')
        return when {
            "unityplayer.dll" in names || "unityplayer.so" in names ||
                (names.any { it.endsWith("_data") } && names.any { it.endsWith(".exe") } && "mono" in names) -> Engine.UNITY
            exeName.contains("-win64-shipping") || exeName.contains("-win32-shipping") ||
                path.contains("/binaries/win64") || path.contains("/binaries/linux") ||
                hasUp(dir, "engine", 3) -> Engine.UNREAL
            names.any { it.endsWith(".pck") } || exeName.contains("godot") -> Engine.GODOT
            "hl2.exe" in names || "srcds.exe" in names -> Engine.SOURCE
            else -> Engine.UNKNOWN
        }
    }

    private fun hasUp(start: File?, name: String, levels: Int): Boolean {
        var d = start
        repeat(levels) {
            d = d?.parentFile ?: return false
            if (d!!.list()?.any { it.equals(name, true) } == true &&
                d!!.list()?.any { it.equals("binaries", true) } == true) return true
        }
        return false
    }

    private fun detectAntiCheat(dir: File?): String? {
        var d = dir
        repeat(3) {
            val n = d?.list()?.map { it.lowercase() } ?: emptyList()
            when {
                n.any { it.startsWith("easyanticheat") } -> return "EasyAntiCheat"
                n.any { it.startsWith("battleye") || it.startsWith("beclient") } -> return "BattlEye"
                "vgc.exe" in n -> return "Vanguard"
                n.any { it.startsWith("gameguard") || it.startsWith("xigncode") } -> return "GameGuard/XIGNCODE"
            }
            d = d?.parentFile
        }
        return null
    }

    // ---------- PE (Windows exe) ----------

    private class PeResult(val arch: Arch, val imports: Set<String>, val dotNet: Boolean)

    private fun parsePe(file: File): PeResult? {
        try {
            RandomAccessFile(file, "r").use { f ->
                val n = minOf(f.length(), 16384L).toInt()
                if (n < 0x100) return null
                val h = ByteArray(n)
                f.readFully(h)
                val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
                fun u16(o: Int) = b.getShort(o).toInt() and 0xFFFF
                fun u32(o: Int) = b.getInt(o).toLong() and 0xFFFFFFFFL

                if (u16(0) != 0x5A4D) return null // "MZ"
                val pe = u32(0x3C).toInt()
                if (pe < 0 || pe + 24 > n || u32(pe) != 0x4550L) return null // "PE\0\0"

                val arch = when (u16(pe + 4)) {
                    0x14C -> Arch.X86
                    0x8664 -> Arch.X64
                    0xAA64 -> Arch.ARM64
                    else -> Arch.UNKNOWN
                }
                val nSec = u16(pe + 6)
                val optSize = u16(pe + 20)
                val opt = pe + 24
                val plus = u16(opt) == 0x20B
                val dd = opt + if (plus) 112 else 96
                if (dd + 15 * 8 > n) return null
                val impRva = u32(dd + 8)       // Import Directory
                val clrRva = u32(dd + 14 * 8)  // CLR header (.NET)

                class Sec(val va: Long, val span: Long, val raw: Long)
                val secs = ArrayList<Sec>()
                val table = opt + optSize
                for (i in 0 until nSec) {
                    val s = table + i * 40
                    if (s + 40 > n) break
                    val vsize = u32(s + 8)
                    val va = u32(s + 12)
                    val rsize = u32(s + 16)
                    val raw = u32(s + 20)
                    secs += Sec(va, maxOf(vsize, rsize), raw)
                }
                fun rvaToOff(rva: Long): Long {
                    for (s in secs) if (rva >= s.va && rva < s.va + s.span) return s.raw + (rva - s.va)
                    return -1
                }

                val imports = linkedSetOf<String>()
                val impOff = if (impRva != 0L) rvaToOff(impRva) else -1L
                if (impOff > 0) {
                    for (i in 0 until 512) {
                        f.seek(impOff + i * 20L)
                        val d = ByteArray(20)
                        f.readFully(d)
                        if (d.all { it == 0.toByte() }) break
                        val nameRva = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN).getInt(12).toLong() and 0xFFFFFFFFL
                        val no = rvaToOff(nameRva)
                        if (no < 0) continue
                        f.seek(no)
                        val nb = ByteArray(64)
                        val r = f.read(nb)
                        if (r <= 0) continue
                        var end = nb.indexOf(0.toByte())
                        if (end < 0 || end > r) end = r
                        imports += String(nb, 0, end, Charsets.ISO_8859_1).lowercase()
                    }
                }
                return PeResult(arch, imports, clrRva != 0L)
            }
        } catch (e: Exception) {
            return null
        }
    }

    // ---------- ELF (Linux) ----------

    private fun parseElfArch(file: File): Arch? {
        try {
            RandomAccessFile(file, "r").use { f ->
                if (f.length() < 20) return null
                val h = ByteArray(20)
                f.readFully(h)
                if (h[0] != 0x7F.toByte() || h[1] != 'E'.code.toByte() || h[2] != 'L'.code.toByte() || h[3] != 'F'.code.toByte()) return null
                val machine = (h[0x12].toInt() and 0xFF) or ((h[0x13].toInt() and 0xFF) shl 8)
                return when (machine) {
                    0x3E -> Arch.X64
                    0x03 -> Arch.X86
                    0xB7 -> Arch.ARM64
                    else -> Arch.UNKNOWN
                }
            }
        } catch (e: Exception) {
            return null
        }
    }

    // ---------- поиск строк ----------

    private val DLL_TO_API = mapOf(
        "d3d8.dll" to GfxApi.D3D8,
        "d3d9.dll" to GfxApi.D3D9,
        "d3d10.dll" to GfxApi.D3D10,
        "d3d10_1.dll" to GfxApi.D3D10,
        "d3d11.dll" to GfxApi.D3D11,
        "d3d12.dll" to GfxApi.D3D12,
        "opengl32.dll" to GfxApi.OPENGL,
        "vulkan-1.dll" to GfxApi.VULKAN,
    )
    private val LINUX_NEEDLES = mapOf(
        "libvulkan" to GfxApi.VULKAN,
        "libgl.so" to GfxApi.OPENGL,
    )

    private fun scanAscii(file: File, needles: List<String>, maxBytes: Long = 64L shl 20): Set<String> {
        val found = linkedSetOf<String>()
        try {
            file.inputStream().buffered().use { ins ->
                val buf = ByteArray(1 shl 20)
                var carry = ""
                var total = 0L
                while (total < maxBytes && found.size < needles.size) {
                    val r = ins.read(buf)
                    if (r <= 0) break
                    total += r
                    val s = carry + String(buf, 0, r, Charsets.ISO_8859_1).lowercase()
                    for (nd in needles) if (nd !in found && s.contains(nd)) found += nd
                    carry = s.takeLast(32)
                }
            }
        } catch (_: Exception) {
        }
        return found
    }
}
