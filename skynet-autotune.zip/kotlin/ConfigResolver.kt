package com.skynetemu.autotune

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

enum class Tier { LOW, MID, HIGH }
enum class Vendor { QUALCOMM, MEDIATEK, SAMSUNG, OTHER }

data class DeviceProfile(val soc: String, val vendor: Vendor, val tier: Tier, val activeCooling: Boolean)

/** Итоговые настройки. Названия значений подгони под свой форк в ContainerAccess. */
data class TunedConfig(
    val wrapper: String,          // "dxvk" | "vkd3d" | "wined3d" | "native"
    val box64Preset: String,      // "stability" | "compatibility" | "intermediate" | "performance"
    val resolutionScale: Float,   // 0.5..1.0
    val fpsCap: Int,
    val env: Map<String, String>,
    val dependencies: List<String>,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("wrapper", wrapper).put("box64", box64Preset)
        .put("resScale", resolutionScale.toDouble()).put("fpsCap", fpsCap)
        .put("env", JSONObject(env)).put("deps", JSONArray(dependencies))

    companion object {
        fun fromJson(o: JSONObject): TunedConfig {
            val e = o.optJSONObject("env") ?: JSONObject()
            val d = o.optJSONArray("deps") ?: JSONArray()
            return TunedConfig(
                o.optString("wrapper", "dxvk"), o.optString("box64", "stability"),
                o.optDouble("resScale", 1.0).toFloat(), o.optInt("fpsCap", 60),
                e.keys().asSequence().associateWith { e.getString(it) },
                (0 until d.length()).map { d.getString(it) },
            )
        }
    }
}

data class Resolution(
    val key: String,
    val primary: TunedConfig,
    val fallbacks: List<TunedConfig>,   // лесенка: каждый следующий безопаснее
    val warnings: List<String>,
    val source: String,                 // "last-good" | "rules"
)

object DeviceDetector {
    fun detect(activeCooling: Boolean): DeviceProfile {
        val api31 = Build.VERSION.SDK_INT >= 31
        val model = (if (api31) Build.SOC_MODEL else Build.HARDWARE).uppercase()
        val maker = (if (api31) Build.SOC_MANUFACTURER else Build.MANUFACTURER).lowercase()
        val vendor = when {
            maker.contains("qualcomm") || model.startsWith("SM") || model.startsWith("SG") || model.startsWith("QCOM") -> Vendor.QUALCOMM
            maker.contains("mediatek") || model.startsWith("MT") -> Vendor.MEDIATEK
            maker.contains("samsung") || model.startsWith("EXYNOS") || model.startsWith("S5E") -> Vendor.SAMSUNG
            else -> Vendor.OTHER
        }
        val n = Regex("SM(\\d{4})").find(model)?.groupValues?.get(1)?.toIntOrNull()
        val tier = when {
            n == null -> Tier.MID          // не смогли распознать — берём середину
            n >= 8450 -> Tier.HIGH         // 8 Gen 1 и новее
            n >= 8250 -> Tier.MID          // 865 / 888
            else -> Tier.LOW
        }
        return DeviceProfile(model, vendor, tier, activeCooling)
    }
}

/** Правила лежат в assets/autotune_rules.json, а свежую версию можно тянуть с GitHub. */
object RulesLoader {
    /** Впиши raw-ссылку на свой rules.json в репозитории. Пусто = только встроенный файл. */
    const val REMOTE_URL = ""

    /** Вызывать НЕ с главного потока. */
    fun load(ctx: Context): JSONObject {
        val cache = File(ctx.filesDir, "autotune_rules.json")
        if (REMOTE_URL.isNotBlank()) {
            try {
                val c = URL(REMOTE_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 5000
                c.readTimeout = 5000
                if (c.responseCode == 200) {
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    JSONObject(text) // проверка, что это валидный JSON
                    cache.writeText(text)
                }
                c.disconnect()
            } catch (_: Exception) {
            }
        }
        val text = if (cache.exists()) cache.readText()
        else ctx.assets.open("autotune_rules.json").bufferedReader().use { it.readText() }
        return JSONObject(text)
    }
}

/** «Опыт»: запоминает конфиг, с которым игра реально запустилась. */
class LastGoodStore(private val file: File) {
    private fun read(): JSONObject = try { JSONObject(file.readText()) } catch (_: Exception) { JSONObject() }
    fun get(key: String): TunedConfig? = read().optJSONObject(key)?.let { TunedConfig.fromJson(it) }
    fun save(key: String, cfg: TunedConfig) { file.writeText(read().put(key, cfg.toJson()).toString()) }
    fun forget(key: String) { file.writeText(read().apply { remove(key) }.toString()) }
}

object Box64Presets {
    // Стартовые значения по документации Box64. Если в форке уже есть встроенные пресеты — используй их по имени.
    fun env(preset: String): Map<String, String> = when (preset) {
        "stability" -> mapOf("BOX64_DYNAREC_SAFEFLAGS" to "2", "BOX64_DYNAREC_BIGBLOCK" to "0", "BOX64_DYNAREC_STRONGMEM" to "2",
            "BOX64_DYNAREC_FASTNAN" to "0", "BOX64_DYNAREC_FASTROUND" to "0", "BOX64_DYNAREC_X87DOUBLE" to "1")
        "compatibility" -> mapOf("BOX64_DYNAREC_SAFEFLAGS" to "2", "BOX64_DYNAREC_BIGBLOCK" to "0", "BOX64_DYNAREC_STRONGMEM" to "1",
            "BOX64_DYNAREC_FASTNAN" to "0", "BOX64_DYNAREC_FASTROUND" to "0", "BOX64_DYNAREC_X87DOUBLE" to "1")
        "performance" -> mapOf("BOX64_DYNAREC_SAFEFLAGS" to "0", "BOX64_DYNAREC_BIGBLOCK" to "3", "BOX64_DYNAREC_STRONGMEM" to "0",
            "BOX64_DYNAREC_FASTNAN" to "1", "BOX64_DYNAREC_FASTROUND" to "1", "BOX64_DYNAREC_X87DOUBLE" to "0")
        else -> mapOf("BOX64_DYNAREC_SAFEFLAGS" to "1", "BOX64_DYNAREC_BIGBLOCK" to "1", "BOX64_DYNAREC_STRONGMEM" to "0",
            "BOX64_DYNAREC_FASTNAN" to "1", "BOX64_DYNAREC_FASTROUND" to "0", "BOX64_DYNAREC_X87DOUBLE" to "1")
    }
    val SAFETY_ORDER = listOf("stability", "compatibility", "intermediate", "performance")
    fun safer(a: String, b: String) =
        if (SAFETY_ORDER.indexOf(a).let { if (it < 0) 99 else it } <= SAFETY_ORDER.indexOf(b).let { if (it < 0) 99 else it }) a else b
}

class ConfigResolver(private val rules: JSONObject, private val store: LastGoodStore? = null) {

    companion object {
        fun keyFor(game: GameInfo, device: DeviceProfile) = game.exe.name.lowercase() + "|" + device.tier
    }

    fun resolve(game: GameInfo, device: DeviceProfile): Resolution {
        val key = keyFor(game, device)
        val warnings = mutableListOf<String>()
        game.antiCheat?.let { warnings += "Найден античит ($it): под Wine/Box64 такие игры обычно не запускаются." }
        if (device.vendor != Vendor.QUALCOMM) warnings += "GPU не Adreno: драйвер Turnip недоступен, возможны проблемы с графикой."

        // 1) опыт: если уже запускалось — берём этот конфиг
        store?.get(key)?.let { return Resolution(key, it, ladder(it), warnings, "last-good") }

        // 2) база правил
        val t = rules.getJSONObject("tiers").getJSONObject(device.tier.name)
        var res = t.optDouble("resScale", 1.0).toFloat()
        var fps = t.optInt("fpsCap", 60)
        var box = t.optString("box64", "intermediate")
        var wrapper = if (game.platform == Platform.LINUX) "native" else "dxvk"
        val env = linkedMapOf<String, String>()
        val deps = linkedSetOf<String>()

        if (game.platform != Platform.LINUX) {
            val api = game.highestD3D ?: game.gfxApis.firstOrNull()
            api?.let { rules.optJSONObject("gfx")?.optJSONObject(it.name)?.optString("wrapper")?.takeIf { w -> w.isNotEmpty() }?.let { w -> wrapper = w } }
        }

        rules.optJSONObject("engines")?.optJSONObject(game.engine.name)?.let { e ->
            res *= e.optDouble("resScaleMul", 1.0).toFloat()
            if (e.has("box64")) box = Box64Presets.safer(box, e.getString("box64"))
            if (e.has("fpsCap")) fps = minOf(fps, e.getInt("fpsCap"))
            e.optJSONObject("env")?.let { o -> o.keys().forEach { k -> env[k] = o.getString(k) } }
        }

        if (game.usesDotNet) rules.optJSONObject("dotnet")?.optJSONArray("deps")?.let { a -> for (i in 0 until a.length()) deps += a.getString(i) }

        // 3) точечные правила для конкретной игры (по имени exe) — приоритетнее всего
        rules.optJSONObject("games")?.optJSONObject(game.exe.name.lowercase())?.let { g ->
            g.optString("wrapper").takeIf { it.isNotEmpty() }?.let { wrapper = it }
            g.optString("box64").takeIf { it.isNotEmpty() }?.let { box = it }
            if (g.has("resScale")) res = g.getDouble("resScale").toFloat()
            if (g.has("fpsCap")) fps = g.getInt("fpsCap")
            g.optJSONObject("env")?.let { o -> o.keys().forEach { k -> env[k] = o.getString(k) } }
            g.optJSONArray("deps")?.let { a -> for (i in 0 until a.length()) deps += a.getString(i) }
        }

        // кулер (например Flydigi B9X) снижает троттлинг -> можно чуть выше разрешение
        if (device.activeCooling) res += 0.1f
        res = res.coerceIn(0.5f, 1.0f)
        if (wrapper == "dxvk") env["DXVK_FRAME_RATE"] = fps.toString()

        val cfg = TunedConfig(wrapper, box, res, fps, env, deps.toList())
        return Resolution(key, cfg, ladder(cfg), warnings, "rules")
    }

    /** Лесенка отката: максимум 3 заранее известных, всё более безопасных шага. Никакого перебора. */
    private fun ladder(c: TunedConfig): List<TunedConfig> {
        fun TunedConfig.withFps(f: Int) = copy(
            fpsCap = f,
            env = if ("DXVK_FRAME_RATE" in env) env + ("DXVK_FRAME_RATE" to f.toString()) else env,
        )
        val steps = mutableListOf<TunedConfig>()
        val s1 = c.copy(box64Preset = "stability")
        steps += s1
        val s2 = s1.copy(resolutionScale = (c.resolutionScale * 0.75f).coerceAtLeast(0.5f)).withFps(minOf(c.fpsCap, 30))
        steps += s2
        val alt = when (c.wrapper) { "dxvk" -> "wined3d"; "wined3d" -> "dxvk"; else -> null }
        if (alt != null) steps += s2.copy(wrapper = alt, env = s2.env - "DXVK_FRAME_RATE", resolutionScale = 0.6f)
        return steps.filter { it != c }.distinct()
    }
}
