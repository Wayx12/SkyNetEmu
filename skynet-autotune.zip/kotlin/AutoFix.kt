package com.skynetemu.autotune

import java.io.File

sealed interface FixAction {
    data object ClearShaderCache : FixAction
    data object RecreatePrefix : FixAction
    data object LowerResolution : FixAction
    data class InstallDependency(val name: String) : FixAction
    data class SetBox64Preset(val preset: String) : FixAction
    data class SwitchWrapper(val to: String) : FixAction
    data class Warn(val message: String) : FixAction
}

/**
 * ЕДИНСТВЕННОЕ место, которое надо связать с кодом форка (адаптер).
 * Всё остальное в модуле от кода SkyNetEmu не зависит.
 */
interface ContainerAccess {
    val root: File                                  // корень контейнера
    fun setBox64Preset(preset: String)
    fun setWrapper(wrapper: String)
    fun scaleResolution(factor: Float)
    fun applyConfig(cfg: TunedConfig)               // применить целиком конфиг из лесенки
    fun installDependency(name: String): Boolean    // "vcredist" | "directx9" | "dotnet48" ...
    /** Обязательно сделай копию сохранений (drive_c/users/...) и верни папку бэкапа, потом пересоздай префикс. */
    fun backupUserData(): File?
    fun recreatePrefix(): Boolean
}

data class RepairReport(val applied: List<String>, val warnings: List<String>, val usedFallback: Boolean)

object AutoFix {

    private data class Sig(val regex: Regex, val actions: (MatchResult) -> List<FixAction>)

    private fun depForDll(dll: String): FixAction {
        val d = dll.lowercase()
        return when {
            Regex("^(msvcp|vcruntime|msvcr|concrt|ucrtbase|mfc)").containsMatchIn(d) -> FixAction.InstallDependency("vcredist")
            Regex("^(d3dx9|d3dx10|d3dx11|d3dcompiler|xinput|xaudio|x3daudio|xapofx)").containsMatchIn(d) -> FixAction.InstallDependency("directx9")
            Regex("^(mscoree|clr)").containsMatchIn(d) -> FixAction.InstallDependency("dotnet48")
            else -> FixAction.Warn("Не хватает библиотеки $dll — нужна ручная установка.")
        }
    }

    private val SIGS = listOf(
        Sig(Regex("Library\\s+(\\S+\\.dll)\\b.*not found", RegexOption.IGNORE_CASE)) { listOf(depForDll(it.groupValues[1])) },
        Sig(Regex("VK_ERROR_(DEVICE_LOST|OUT_OF_DEVICE_MEMORY|OUT_OF_HOST_MEMORY)")) { listOf(FixAction.ClearShaderCache, FixAction.LowerResolution) },
        Sig(Regex("VK_ERROR_(INITIALIZATION_FAILED|INCOMPATIBLE_DRIVER|EXTENSION_NOT_PRESENT)|Failed to create D3D1[01] device|D3D11CreateDevice.*fail", RegexOption.IGNORE_CASE)) {
            listOf(FixAction.SwitchWrapper("wined3d"), FixAction.Warn("DXVK не смог создать устройство Vulkan — переключаю на WineD3D."))
        },
        Sig(Regex("SIGILL|Illegal instruction|Unimplemented Opcode|Unsupported Opcode", RegexOption.IGNORE_CASE)) { listOf(FixAction.SetBox64Preset("stability")) },
        Sig(Regex("SIGSEGV|SIGBUS|Segmentation fault|Unhandled page fault", RegexOption.IGNORE_CASE)) { listOf(FixAction.SetBox64Preset("stability"), FixAction.ClearShaderCache) },
        Sig(Regex("wine: (could not load|failed to open).*(kernel32|ntdll)|wineserver: .*(version mismatch|Permission denied)|prefix.*(corrupt|outdated)|configuration directory.*(invalid|not owned)", RegexOption.IGNORE_CASE)) { listOf(FixAction.RecreatePrefix) },
        Sig(Regex("Out of memory|std::bad_alloc|Cannot allocate memory|lowmemorykiller", RegexOption.IGNORE_CASE)) { listOf(FixAction.LowerResolution, FixAction.Warn("Не хватает памяти: снижаю разрешение.")) },
        Sig(Regex("Could not load (file or )?assembly|System\\.IO\\.FileNotFoundException|mscoree", RegexOption.IGNORE_CASE)) { listOf(FixAction.InstallDependency("dotnet48")) },
        Sig(Regex("EasyAntiCheat|BattlEye|BEService|XIGNCODE|GameGuard", RegexOption.IGNORE_CASE)) { listOf(FixAction.Warn("Игра использует античит — под Wine/Box64 это обычно не лечится.")) },
        Sig(Regex("unimplemented function (\\S+)", RegexOption.IGNORE_CASE)) { listOf(FixAction.Warn("Wine не реализует функцию ${it.groupValues[1]} — нужен другой билд Wine/Proton.")) },
        Sig(Regex("Cannot open display|X connection|xcb.*(assert|fail)", RegexOption.IGNORE_CASE)) { listOf(FixAction.Warn("Сбой X-сервера — перезапусти контейнер.")) },
    )

    fun diagnose(log: String): List<FixAction> {
        val out = linkedSetOf<FixAction>()
        for (sig in SIGS) sig.regex.findAll(log).forEach { m -> out += sig.actions(m) }
        // безопасный порядок: сначала дешёвое и обратимое, пересоздание префикса — в самом конце
        return out.sortedBy { if (it is FixAction.RecreatePrefix) 1 else 0 }
    }

    /**
     * attempt = номер попытки ремонта (0, 1, 2…). Если по логу ничего не опознано —
     * берётся следующий шаг лесенки из Resolution.fallbacks.
     */
    fun repair(log: String, access: ContainerAccess, resolution: Resolution, attempt: Int): RepairReport {
        val actions = diagnose(log)
        val applied = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        var usedFallback = false

        for (a in actions) when (a) {
            is FixAction.ClearShaderCache -> { val n = clearShaderCaches(access.root); applied += "Очищен кеш шейдеров ($n)" }
            is FixAction.SetBox64Preset -> { access.setBox64Preset(a.preset); applied += "Box64: пресет ${a.preset}" }
            is FixAction.SwitchWrapper -> { access.setWrapper(a.to); applied += "Рендер: ${a.to}" }
            is FixAction.LowerResolution -> { access.scaleResolution(0.75f); applied += "Разрешение ×0.75" }
            is FixAction.InstallDependency -> applied += if (access.installDependency(a.name)) "Установлено: ${a.name}" else "Не удалось установить: ${a.name}"
            is FixAction.RecreatePrefix -> {
                val backup = access.backupUserData()
                if (backup == null) warnings += "Не удалось сохранить сохранения — префикс НЕ пересоздан."
                else applied += if (access.recreatePrefix()) "Префикс пересоздан (бэкап: ${backup.name})" else "Не удалось пересоздать префикс"
            }
            is FixAction.Warn -> warnings += a.message
        }

        val fixedSomething = actions.any { it !is FixAction.Warn }
        if (!fixedSomething) {
            resolution.fallbacks.getOrNull(attempt)?.let {
                access.applyConfig(it); usedFallback = true
                applied += "Применён безопасный конфиг №${attempt + 1} (${it.wrapper}, ${it.box64Preset}, ×${"%.2f".format(it.resolutionScale)})"
            } ?: warnings.add("Безопасные конфиги закончились — нужен ручной разбор лога.")
        }
        return RepairReport(applied, warnings, usedFallback)
    }

    /** Чистит ТОЛЬКО кеши (шейдеры/пайплайны). Сохранения и файлы игры не трогает. */
    fun clearShaderCaches(root: File): Int {
        var n = 0
        root.walkTopDown().maxDepth(12).forEach { f ->
            val name = f.name.lowercase()
            val isCacheFile = f.isFile && (name.endsWith(".dxvk-cache") || name.startsWith("vkd3d-proton.cache"))
            val isCacheDir = f.isDirectory && (name == "mesa_shader_cache" || name == "mesa_shader_cache_db")
            if (isCacheFile && f.delete()) n++
            else if (isCacheDir && f.deleteRecursively()) n++
        }
        return n
    }
}
