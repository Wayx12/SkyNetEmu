# SkyNet AutoTune — автонастройка и автофикс игр

Модуль для форка SkyNetEmu (GPL-3.0 — форк тоже должен остаться открытым).
Игру НЕ гоняет в тестах: настройки берутся из правил и опыта.

## Что внутри
- `GameAnalyzer.kt` — читает exe/ELF: разрядность, DirectX/Vulkan/OpenGL, движок (Unity/Unreal/Godot/Source), .NET, античит.
- `ConfigResolver.kt` — уровень телефона (по SoC) + правила → конфиг и «лесенка» из 3 безопасных запасных. Запоминает рабочий конфиг.
- `AutoFix.kt` — читает лог, находит причину (нет DLL, краш Box64, Vulkan, битый префикс...) и чинит. Сохранения не трогает.
- `AutoTune.kt` — фасад, 3 вызова.
- `autotune_rules.json` — правила. Можно тянуть с GitHub (`RulesLoader.REMOTE_URL`).

## Как встроить (4 шага)
1. Форкни репозиторий SkyNetEmu на GitHub.
2. `kotlin/*.kt` → `app/src/main/java/com/skynetemu/autotune/`; `autotune_rules.json` → `app/src/main/assets/`.
3. Реализуй `ContainerAccess` (8 методов) поверх кода контейнеров форка. Это единственная связка.
4. Кнопка «Автонастройка» вызывает `AutoTune.prepare(...)` и `access.applyConfig(r.primary)`; при падении игры — `AutoFix.repair(...)`.

## Как получить APK без ПК
Запушь форк на GitHub и собери через GitHub Actions (если в репозитории есть workflow сборки, всё само) либо через Codespaces: `./gradlew assembleRelease`.

## Важно
Код написан без компиляции и проверки на устройстве. Возможны мелкие правки при первой сборке.
Значения пресетов Box64 и правила движков — стартовые, их надо подтверждать на реальных играх.
